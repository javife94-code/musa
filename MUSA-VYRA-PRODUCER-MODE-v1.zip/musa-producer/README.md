# MUSA // VYRA PRODUCER MODE v1

Control de FL Studio por voz y texto desde MUSA.

---

## Requisitos

- Windows 10 o 11
- Node.js 18 o superior → https://nodejs.org
- FL Studio (cualquier versión reciente)
- loopMIDI (gratuito) → https://www.tobias-erichsen.de/software/loopmidi.html

---

## Instalación — 4 pasos

### Paso 1 — Instala las dependencias

Abre la carpeta del proyecto en la terminal (o haz clic derecho → "Abrir en Terminal") y escribe:

```
npm install
```

Espera a que termine. Solo hay que hacerlo una vez.

### Paso 2 — Instala el script en FL Studio

Sigue las instrucciones de `fl-studio/README-FL-STUDIO.md`.

En resumen:
1. Instala loopMIDI y crea el puerto `MUSA FL Bridge`
2. Copia `fl-studio/device_VyraMusa.py` a la carpeta `Hardware specific` de FL Studio
3. En FL Studio → Options → MIDI Settings, selecciona el puerto y el controlador `VYRA MUSA BRIDGE`

### Paso 3 — Abre MUSA

```
npm start
```

MUSA se abre como aplicación de escritorio.

### Paso 4 — Activa Producer Mode

- Pulsa el botón **🎛 PROD** en la barra de navegación inferior
- O di: **"Vyra, abre FL Studio"**
- Pulsa **COMPROBAR PUENTE** para verificar la conexión

---

## Comandos de voz disponibles

| Lo que dices | Lo que hace |
|---|---|
| "Vyra, abre FL Studio" | Abre FL Studio |
| "Dale al play" / "Reproduce" | Inicia la reproducción |
| "Para" / "Stop" | Detiene la reproducción |
| "Graba" / "Empieza a grabar" | Activa/desactiva grabación |
| "Metrónomo" | Activa/desactiva metrónomo |
| "Abre el mixer" / "Mezclador" | Abre el Mixer |
| "Abre el Piano Roll" | Abre el Piano Roll |
| "Playlist" | Abre la Playlist |
| "Ponlo a 140 BPM" | Cambia el tempo a 140 |
| "Patrón 4" / "Ve al patrón 4" | Selecciona el patrón 4 |
| "Silencia" / "Mute" | Silencia el canal seleccionado |
| "Solo" | Pone en solo el canal seleccionado |
| "Guarda una nueva versión" | Guarda nueva versión (con confirmación) |

---

## Estado de las funciones

### ✅ Implementadas y funcionales

- Abrir FL Studio
- Play / Stop / Record
- Metrónomo
- Abrir Mixer, Playlist, Piano Roll, Browser, Channel Rack
- Cambiar tempo (40–300 BPM, validado)
- Seleccionar patrón (1–16)
- Silenciar / Solo del canal seleccionado
- Guardar nueva versión (con confirmación de diálogo)
- Panel visual con estado en tiempo real
- Historial de últimas 10 acciones
- Reconocimiento de voz con variaciones naturales
- Deduplicación de comandos (ventana 1.5s)
- Whitelist cerrada de acciones
- Respuestas de voz con Vyra
- Degradación elegante cuando FL no está disponible

### ⏳ Pendientes para próximas versiones

- Feedback de confirmación desde FL Studio (actualmente el puente envía el comando pero no recibe ACK)
- Volumen de canal por voz
- Exportar audio (requiere manejo de diálogos del SO)
- Soporte para múltiples instancias de FL Studio
- Detección automática del proyecto activo
- Modo canción / patrón por voz
- Undo / Redo

---

## Solución de problemas

**MUSA dice "requiere MUSA Desktop"**
→ Asegúrate de abrirlo con `npm start`, no con doble clic en el HTML.

**"Puente no disponible"**
→ Comprueba que loopMIDI está activo y que el script está instalado en FL Studio.

**"No encuentro FL Studio"**
→ Ve a Ajustes → VYRA PRODUCER y escribe la ruta completa al ejecutable.

**Los botones no hacen nada**
→ FL Studio debe estar abierto y el script MIDI activo antes de enviar comandos.
