'use strict';

/**
 * FL Bridge — MUSA ↔ FL Studio communication layer
 *
 * Communication strategy (in priority order):
 *   1. FL Studio MIDI scripting via easymidi (requires MIDI loopback port)
 *   2. OSC via node-osc (requires MIDI Scripting script installed in FL)
 *   3. Graceful degradation — returns structured errors, never crashes MUSA
 *
 * The bridge is self-contained: if FL Studio is closed or MIDI is missing,
 * MUSA continues working normally. Only Producer Mode features are disabled.
 */

let midi = null;
let osc  = null;

// Lazy-load optional dependencies
try { midi = require('easymidi'); } catch (e) { /* MIDI not installed */ }
try {
  const { Client } = require('node-osc');
  osc = Client;
} catch (e) { /* OSC not installed */ }

// ── State ──────────────────────────────────────────────────────
let _output       = null;   // MIDI output port
let _oscClient    = null;   // OSC client
let _available    = false;
let _mainWindow   = null;
let _stats        = { commandsSent: 0, errors: 0, lastSeen: null };

const FL_MIDI_PORT_NAME = 'MUSA FL Bridge';   // Virtual MIDI port name in FL Studio
const FL_OSC_HOST       = '127.0.0.1';
const FL_OSC_PORT       = 9000;               // Must match FL Studio OSC script config

// ── CC assignments (FL Studio default MIDI mapping) ───────────
const CC = {
  PLAY:          0x73,   // CC 115
  STOP:          0x74,   // CC 116
  RECORD:        0x75,   // CC 117
  METRONOME:     0x59,   // CC 89
  TEMPO_COARSE:  0x0C,   // CC 12
  TEMPO_FINE:    0x0D,   // CC 13
};

// ── Note assignments for window open ──────────────────────────
const NOTES = {
  MIXER:      0x00,
  PLAYLIST:   0x01,
  PIANO_ROLL: 0x02,
  BROWSER:    0x03,
  CHANNEL_RACK: 0x04
};

// ─────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────

function init(mainWindow) {
  _mainWindow = mainWindow;
  _tryConnect();
  // Reconnect attempt every 5 seconds
  setInterval(_tryConnect, 5000);
}

function isAvailable() { return _available; }

function stats() {
  return { ..._stats, available: _available };
}

async function detect() {
  if (!midi) return { found: false, reason: 'easymidi no instalado. Ejecuta npm install.' };
  try {
    const outputs = midi.getOutputs();
    const found = outputs.some(o => o.toLowerCase().includes('fl') || o.toLowerCase().includes('midi'));
    return { found, ports: outputs, reason: found ? 'Puerto MIDI encontrado.' : 'No se encontró puerto MIDI de FL Studio. Asegúrate de que FL Studio está abierto y el script MIDI está activo.' };
  } catch (e) {
    return { found: false, reason: e.message };
  }
}

async function execute(action, params) {
  _stats.commandsSent++;
  _stats.lastSeen = new Date().toISOString();

  switch (action) {

    // ── Transport ──────────────────────────────────────────
    case 'fl:open':      return _openFLStudio();
    case 'fl:play':      return _sendCC(CC.PLAY, 127);
    case 'fl:stop':      return _sendCC(CC.STOP, 127);
    case 'fl:record':    return _sendCC(CC.RECORD, 127);
    case 'fl:metronome': return _sendCC(CC.METRONOME, params.on ? 127 : 0);

    // ── Tempo ──────────────────────────────────────────────
    case 'fl:set-tempo':
      return _setTempo(params.bpm);

    // ── Windows ───────────────────────────────────────────
    case 'fl:open-mixer':       return _sendNote(NOTES.MIXER);
    case 'fl:open-playlist':    return _sendNote(NOTES.PLAYLIST);
    case 'fl:open-piano-roll':  return _sendNote(NOTES.PIANO_ROLL);
    case 'fl:open-browser':     return _sendNote(NOTES.BROWSER);
    case 'fl:open-channel-rack':return _sendNote(NOTES.CHANNEL_RACK);

    // ── Channels & Patterns ───────────────────────────────
    case 'fl:select-pattern':
      return _sendCC(0x20, Math.max(0, Math.min(127, (params.index || 0))));
    case 'fl:select-channel':
      return _sendCC(0x21, Math.max(0, Math.min(127, (params.index || 0))));
    case 'fl:mute-channel':
      return _sendCC(0x22, params.mute ? 127 : 0);
    case 'fl:solo-channel':
      return _sendCC(0x23, params.solo ? 127 : 0);

    // ── Save (confirmed by main.js before reaching here) ──
    case 'fl:save-new':
      return _sendCC(0x50, 127);

    // ── Close FL (confirmed by main.js) ───────────────────
    case 'fl:close':
      return _sendCC(0x51, 127);

    // ── Status ────────────────────────────────────────────
    case 'fl:status':
      return { status: 'alive', available: _available, stats: _stats };

    default:
      throw new Error('Acción no implementada: ' + action);
  }
}

// ─────────────────────────────────────────────────────────────
// Internal helpers
// ─────────────────────────────────────────────────────────────

function _tryConnect() {
  if (!midi) { _available = false; return; }
  try {
    const outputs = midi.getOutputs();
    // Prefer exact match, then any port with 'fl' or 'loopMIDI' or 'virtual'
    let portName = outputs.find(o => o === FL_MIDI_PORT_NAME)
      || outputs.find(o => /fl.studio|fl bridge|musa|loopmidi/i.test(o))
      || outputs[0];

    if (!portName) { _available = false; return; }

    if (!_output || _output.portName !== portName) {
      if (_output) { try { _output.close(); } catch (e) {} }
      _output = new midi.Output(portName);
      _output.portName = portName;
    }
    _available = true;
  } catch (e) {
    _available = false;
    _stats.errors++;
  }
}

function _sendCC(controller, value) {
  if (!_output) throw new Error('Puerto MIDI no disponible.');
  _output.send('cc', { controller, value, channel: 0 });
  return { sent: 'cc', controller, value };
}

function _sendNote(note, velocity = 127) {
  if (!_output) throw new Error('Puerto MIDI no disponible.');
  _output.send('noteon', { note, velocity, channel: 0 });
  setTimeout(() => {
    try { _output.send('noteoff', { note, velocity: 0, channel: 0 }); } catch (e) {}
  }, 50);
  return { sent: 'note', note, velocity };
}

function _setTempo(bpm) {
  const value = parseInt(bpm);
  if (isNaN(value) || value < 40 || value > 300) {
    throw new Error('Tempo inválido: ' + bpm + '. Debe estar entre 40 y 300 BPM.');
  }
  // Send as two CCs: coarse (integer part scaled) and fine
  const coarse = Math.round((value - 40) / 260 * 127);
  _sendCC(CC.TEMPO_COARSE, coarse);
  return { sent: 'tempo', bpm: value };
}

function _openFLStudio() {
  const { exec } = require('child_process');
  // Path stored in secure config, not hardcoded
  // main.js provides it via IPC if needed; here we try common locations
  const paths = [
    process.env.FL_STUDIO_PATH,
    'C:\\Program Files\\Image-Line\\FL Studio 21\\FL64.exe',
    'C:\\Program Files\\Image-Line\\FL Studio 20\\FL64.exe',
    'C:\\Program Files (x86)\\Image-Line\\FL Studio 21\\FL.exe'
  ].filter(Boolean);

  for (const p of paths) {
    try {
      exec('"' + p + '"');
      return { launched: true, path: p };
    } catch (e) { /* try next */ }
  }
  throw new Error('No se encontró FL Studio. Configura la ruta en Ajustes → Producer Mode.');
}

module.exports = { init, isAvailable, detect, execute, stats };
