'use strict';

const { contextBridge, ipcRenderer } = require('electron');

// ── Expose a minimal, typed API to the renderer ───────────────
// No Node.js APIs are exposed directly. All calls go through IPC.

contextBridge.exposeInMainWorld('MusaElectron', {

  // ── Environment detection ─────────────────────────────────
  isElectron: true,

  onStatus(callback) {
    ipcRenderer.on('electron:status', (event, data) => callback(data));
  },

  // ── FL Studio commands ────────────────────────────────────
  // Returns Promise<{ ok: boolean, result?, error?, detail? }>
  fl: {
    command(action, params) {
      return ipcRenderer.invoke('fl:command', { action, params });
    },
    detect() {
      return ipcRenderer.invoke('fl:detect');
    },
    health() {
      return ipcRenderer.invoke('fl:health');
    }
  },

  // ── Secure config (stored in main process, never in renderer) ─
  config: {
    get(key)        { return ipcRenderer.invoke('config:get', key); },
    set(key, value) { return ipcRenderer.invoke('config:set', key, value); },
    delete(key)     { return ipcRenderer.invoke('config:delete', key); }
  },

  // ── Shell ─────────────────────────────────────────────────
  openUrl(url) {
    return ipcRenderer.invoke('shell:open-url', url);
  }
});
