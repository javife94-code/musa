'use strict';

const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const Store = require('electron-store');

// ── Persistent store (never exposed to renderer) ──────────────
const store = new Store({
  name: 'musa-producer-config',
  encryptionKey: 'musa-eter-local-only'
});

// ── FL Bridge (lazy-loaded so missing modules don't crash) ────
let FLBridge = null;
try {
  FLBridge = require('./bridge/fl-bridge');
} catch (e) {
  console.warn('[MUSA] FL Bridge not available:', e.message);
}

let mainWindow = null;

// ── Prevent duplicate command execution ───────────────────────
const recentCommands = new Map(); // commandKey -> timestamp
const DEDUP_WINDOW_MS = 1500;

function isDuplicate(key) {
  const last = recentCommands.get(key);
  const now = Date.now();
  if (last && now - last < DEDUP_WINDOW_MS) return true;
  recentCommands.set(key, now);
  return false;
}

// ── Window ────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#020204',
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    },
    icon: path.join(__dirname, 'assets', 'icon.ico')
  });

  mainWindow.loadFile(path.join(__dirname, 'src', 'musa.html'));

  if (process.argv.includes('--dev')) {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  }

  mainWindow.on('closed', () => { mainWindow = null; });

  // Init FL Bridge once window is ready
  mainWindow.webContents.on('did-finish-load', () => {
    if (FLBridge) FLBridge.init(mainWindow);
    sendElectronStatus();
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (!mainWindow) createWindow(); });

// ── Notify renderer of Electron context ──────────────────────
function sendElectronStatus() {
  if (!mainWindow) return;
  mainWindow.webContents.send('electron:status', {
    isElectron: true,
    flAvailable: FLBridge ? FLBridge.isAvailable() : false,
    platform: process.platform,
    version: app.getVersion()
  });
}

// ─────────────────────────────────────────────────────────────
// IPC HANDLERS — all FL Studio commands go through here
// ─────────────────────────────────────────────────────────────

// Safe actions — no confirmation needed
const SAFE_ACTIONS = new Set([
  'fl:open', 'fl:play', 'fl:stop', 'fl:record',
  'fl:open-mixer', 'fl:open-playlist', 'fl:open-piano-roll',
  'fl:open-browser', 'fl:open-channel-rack',
  'fl:set-tempo', 'fl:metronome',
  'fl:select-pattern', 'fl:select-channel',
  'fl:mute-channel', 'fl:solo-channel',
  'fl:status'
]);

// Actions requiring confirmation
const CONFIRM_ACTIONS = new Set([
  'fl:save-new', 'fl:close', 'fl:export', 'fl:overwrite'
]);

// Prohibited in this phase
const PROHIBITED_ACTIONS = new Set([
  'fl:delete-project', 'fl:exec-terminal', 'fl:install-plugin',
  'fl:download', 'fl:exec-ai-code', 'fl:delete-channel',
  'fl:delete-pattern', 'fl:delete-track'
]);

ipcMain.handle('fl:command', async (event, { action, params }) => {
  // ── Security classification ───────────────────────────────
  if (PROHIBITED_ACTIONS.has(action)) {
    return { ok: false, error: 'PROHIBIDA', detail: 'Acción no permitida en esta fase.' };
  }

  if (!SAFE_ACTIONS.has(action) && !CONFIRM_ACTIONS.has(action)) {
    return { ok: false, error: 'ACCIÓN_DESCONOCIDA', detail: 'Acción no reconocida: ' + action };
  }

  // ── Deduplication ────────────────────────────────────────
  const dedupKey = action + JSON.stringify(params || {});
  if (isDuplicate(dedupKey)) {
    return { ok: false, error: 'DUPLICADA', detail: 'Orden duplicada ignorada.' };
  }

  // ── Confirmation for sensitive actions ────────────────────
  if (CONFIRM_ACTIONS.has(action)) {
    const labels = {
      'fl:save-new': '¿Guardar nueva versión del proyecto?',
      'fl:close': '¿Cerrar FL Studio? Puede haber cambios sin guardar.',
      'fl:export': '¿Exportar y sobrescribir el archivo de audio?',
      'fl:overwrite': '¿Sobrescribir el archivo existente?'
    };
    const { response } = await dialog.showMessageBox(mainWindow, {
      type: 'question',
      buttons: ['Cancelar', 'Confirmar'],
      defaultId: 0,
      cancelId: 0,
      title: 'MUSA — Confirmación requerida',
      message: labels[action] || '¿Confirmar acción?'
    });
    if (response === 0) return { ok: false, error: 'CANCELADA', detail: 'El usuario canceló la acción.' };
  }

  // ── Execute via FL Bridge ─────────────────────────────────
  if (!FLBridge) {
    return { ok: false, error: 'BRIDGE_NO_DISPONIBLE', detail: 'FL Bridge no está cargado. Instala las dependencias.' };
  }

  if (!FLBridge.isAvailable()) {
    return { ok: false, error: 'FL_CERRADO', detail: 'FL Studio no está abierto o el puente no responde.' };
  }

  try {
    const result = await FLBridge.execute(action, params || {});
    return { ok: true, result };
  } catch (e) {
    return { ok: false, error: 'ERROR_BRIDGE', detail: e.message };
  }
});

// Config (stored securely, never in renderer)
ipcMain.handle('config:get', (event, key) => store.get(key));
ipcMain.handle('config:set', (event, key, value) => { store.set(key, value); return true; });
ipcMain.handle('config:delete', (event, key) => { store.delete(key); return true; });

// FL Studio detection
ipcMain.handle('fl:detect', async () => {
  if (!FLBridge) return { found: false, reason: 'Bridge no disponible' };
  return FLBridge.detect();
});

// Bridge health check
ipcMain.handle('fl:health', async () => {
  if (!FLBridge) return { alive: false };
  return { alive: FLBridge.isAvailable(), stats: FLBridge.stats() };
});

// Open external URL safely
ipcMain.handle('shell:open-url', (event, url) => {
  if (url && (url.startsWith('https://') || url.startsWith('http://'))) {
    shell.openExternal(url);
  }
});
