# Instalación del script MIDI de VYRA en FL Studio

## Requisito previo: puerto MIDI virtual

MUSA se comunica con FL Studio a través de un puerto MIDI virtual.
Necesitas instalar **loopMIDI** (gratuito) para crearlo.

### Paso 1 — Instala loopMIDI

1. Descarga loopMIDI desde: https://www.tobias-erichsen.de/software/loopmidi.html
2. Instálalo y ábrelo.
3. En el campo de texto inferior escribe: `MUSA FL Bridge`
4. Pulsa el botón `+` para crear el puerto.
5. Verás que aparece `MUSA FL Bridge` en la lista con estado **Running**.
6. Minimiza loopMIDI a la bandeja del sistema — debe quedar activo siempre.

---

## Paso 2 — Copia el script a FL Studio

1. Abre la carpeta de MIDI Scripting de FL Studio. La ruta habitual es:

```
C:\Program Files\Image-Line\FL Studio 21\System\Hardware specific\
```

Si tienes FL Studio 20 o una versión diferente, busca la misma subcarpeta en tu instalación.

2. Dentro de esa carpeta, **crea una subcarpeta** llamada:

```
VYRA MUSA BRIDGE
```

3. Copia el archivo `device_VyraMusa.py` dentro de esa carpeta. El resultado debe ser:

```
Hardware specific\
  VYRA MUSA BRIDGE\
    device_VyraMusa.py
```

---

## Paso 3 — Activa el script en FL Studio

1. Abre FL Studio.
2. Ve a: **Options → MIDI Settings**
3. En la pestaña **MIDI**, busca la sección **Input**.
4. Selecciona el puerto `MUSA FL Bridge` (el que creaste con loopMIDI).
5. En el desplegable **Controller type**, elige: `VYRA MUSA BRIDGE`
6. Activa el puerto marcando la casilla de la izquierda.
7. Pulsa **OK**.

En la ventana de salida de FL Studio (Output) deberías ver el mensaje:
```
VYRA MUSA BRIDGE: inicializado correctamente.
```

---

## Paso 4 — Configura MUSA Desktop

1. Abre MUSA con `npm start` desde la carpeta del proyecto.
2. Ve a **Ajustes → VYRA PRODUCER**.
3. Pulsa **DETECTAR FL STUDIO** — MUSA buscará automáticamente el ejecutable.
4. Si no lo encuentra, introduce la ruta manualmente: `C:\Program Files\Image-Line\FL Studio 21\FL64.exe`
5. Pulsa **COMPROBAR PUENTE** — debería aparecer `CONECTADO`.

---

## Verificación rápida

Con FL Studio abierto y el script activo, di a MUSA:

- "Vyra, reproduce" → FL Studio debe iniciar la reproducción.
- "Vyra, para" → FL Studio debe detenerse.
- "Vyra, abre el mezclador" → El Mixer debe aparecer.

Si algo no funciona, comprueba que loopMIDI está activo y que el puerto aparece tanto en loopMIDI como en FL Studio MIDI Settings.

---

## Solución de problemas

| Problema | Solución |
|---|---|
| MUSA dice "Puerto MIDI no disponible" | Abre loopMIDI y comprueba que el puerto está activo |
| FL Studio no responde a las órdenes | Comprueba que el script está en la carpeta correcta y el Controller type es VYRA MUSA BRIDGE |
| "FL Studio no encontrado" | Configura la ruta en Ajustes → Producer Mode |
| Los botones del panel no hacen nada | MUSA solo puede controlar FL Studio desde la app Desktop (Electron), no desde el navegador |
