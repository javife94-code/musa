# device_VyraMusa.py
# Script MIDI oficial para FL Studio — VYRA MUSA BRIDGE
# Instalación: copia este archivo a la carpeta de MIDI Scripting de FL Studio
# Ruta habitual: C:\Program Files\Image-Line\FL Studio 21\System\Hardware specific\
# Luego ve a: Options → MIDI Settings → Controller type → VYRA MUSA BRIDGE

import transport
import ui
import channels
import patterns
import mixer
import general
import device

# ── Identificación del dispositivo ────────────────────────────
def getName():
    return 'VYRA MUSA BRIDGE'

# ── CC asignaciones (deben coincidir con fl-bridge.js) ────────
CC_PLAY          = 0x73   # 115
CC_STOP          = 0x74   # 116
CC_RECORD        = 0x75   # 117
CC_METRONOME     = 0x59   # 89
CC_TEMPO_COARSE  = 0x0C   # 12

# Notas para ventanas
NOTE_MIXER       = 0x00
NOTE_PLAYLIST    = 0x01
NOTE_PIANO_ROLL  = 0x02
NOTE_BROWSER     = 0x03
NOTE_CHANNEL_RACK= 0x04

# CCs extra
CC_SELECT_PATTERN = 0x20
CC_SELECT_CHANNEL = 0x21
CC_MUTE_CHANNEL   = 0x22
CC_SOLO_CHANNEL   = 0x23
CC_SAVE_NEW       = 0x50
CC_CLOSE_FL       = 0x51

# ── Inicialización ────────────────────────────────────────────
def OnInit():
    print('VYRA MUSA BRIDGE: inicializado correctamente.')
    device.setHasMetronomeButton(True)
    device.setHasStepScheduler(False)

# ── Cierre ────────────────────────────────────────────────────
def OnDeInit():
    print('VYRA MUSA BRIDGE: desconectado.')

# ── Recepción de mensajes MIDI ─────────────────────────────────
def OnMidiMsg(event):
    event.handled = False

    status = event.status
    data1  = event.data1   # CC number o nota
    data2  = event.data2   # valor

    # ── CC (Control Change) — status 0xB0 = canal 1 ──────────
    if status == 0xB0:
        event.handled = True

        if data1 == CC_PLAY:
            transport.start()
            print('VYRA: Reproduciendo.')

        elif data1 == CC_STOP:
            transport.stop()
            print('VYRA: Detenido.')

        elif data1 == CC_RECORD:
            transport.record()
            print('VYRA: Grabación activada/desactivada.')

        elif data1 == CC_METRONOME:
            # data2 > 63 = activar, data2 <= 63 = desactivar
            on = data2 > 63
            ui.setHintMsg('VYRA: Metrónomo ' + ('ON' if on else 'OFF'))
            transport.globalTransport(106, 1)  # toggle metronome
            print('VYRA: Metrónomo', 'ON' if on else 'OFF')

        elif data1 == CC_TEMPO_COARSE:
            # Reconstruir BPM desde valor 0-127 → 40-300
            bpm = int(40 + (data2 / 127.0) * 260)
            transport.setTempo(bpm)
            ui.setHintMsg('VYRA: Tempo ' + str(bpm) + ' BPM')
            print('VYRA: Tempo establecido en', bpm, 'BPM.')

        elif data1 == CC_SELECT_PATTERN:
            patterns.jumpToPattern(data2 + 1)
            print('VYRA: Patrón', data2 + 1, 'seleccionado.')

        elif data1 == CC_SELECT_CHANNEL:
            channels.selectOneChannel(data2)
            print('VYRA: Canal', data2, 'seleccionado.')

        elif data1 == CC_MUTE_CHANNEL:
            idx = channels.selectedChannel()
            channels.muteChannel(idx, 1 if data2 > 63 else 0)
            print('VYRA: Canal', idx, 'silenciado.')

        elif data1 == CC_SOLO_CHANNEL:
            idx = channels.selectedChannel()
            channels.soloChannel(idx)
            print('VYRA: Canal', idx, 'en solo.')

        elif data1 == CC_SAVE_NEW:
            general.saveProject(1)   # 1 = guardar como nueva versión
            print('VYRA: Nueva versión guardada.')

        elif data1 == CC_CLOSE_FL:
            # Cierre con confirmación — FL mostrará diálogo nativo si hay cambios
            general.closeProject(1)
            print('VYRA: Cerrando FL Studio.')

        else:
            event.handled = False

    # ── Note On — status 0x90 = canal 1 ─────────────────────
    elif status == 0x90 and data2 > 0:
        event.handled = True

        if data1 == NOTE_MIXER:
            ui.showMixer()
            print('VYRA: Mixer abierto.')

        elif data1 == NOTE_PLAYLIST:
            ui.showPlaylist()
            print('VYRA: Playlist abierta.')

        elif data1 == NOTE_PIANO_ROLL:
            ui.showPianoRoll()
            print('VYRA: Piano Roll abierto.')

        elif data1 == NOTE_BROWSER:
            ui.showBrowser()
            print('VYRA: Browser abierto.')

        elif data1 == NOTE_CHANNEL_RACK:
            ui.showChannelRack()
            print('VYRA: Channel Rack abierto.')

        else:
            event.handled = False
